<?php
error_reporting(0);
include_once "inc/sparqllib.php";

$endpoint = "http://sparql.data.southampton.ac.uk";

$allpos = sparql_get($endpoint, '
SELECT ?s ?p ?o WHERE {
    <http://id.southampton.ac.uk/products-and-services/LatteCoffeeLarge> ?p ?o .
  FILTER REGEX(?o, "latte coffee \\\\\\\(", "i")
}
');

print_r($allpos);
foreach($allpos as $p)
{
	var_dump($p);
}


echo "1".htmlspecialchars('"\"')."\n";
echo "2".htmlspecialchars('"\\"')."\n";
echo "3".htmlspecialchars('"\\\"')."\n";
echo "4".htmlspecialchars('"\\\\"')."\n";
echo "5".htmlspecialchars('"\\\\\"')."\n";
echo "6".htmlspecialchars('"\\\\\\"')."\n";
echo "7".htmlspecialchars('"\\\\\\\"')."\n";

//	\\\\\\\(
//	 \ \ \\(

//	\\\\\\\(
//	 \ \ \ (
//         \   (	<= needs to get to SPARQL server
//             (
