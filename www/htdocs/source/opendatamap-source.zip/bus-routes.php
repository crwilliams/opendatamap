<?php
error_reporting(0);
include_once "inc/sparqllib.php";

$endpoint = "http://sparql.data.southampton.ac.uk";

$points = sparql_get($endpoint, "
PREFIX geo: <http://www.w3.org/2003/01/geo/wgs84_pos#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT DISTINCT ?sr ?s ?r ?seq ?number ?name ?lat ?long WHERE {
    ?sr <http://id.southampton.ac.uk/ns/busStoppingAt> ?s .
    ?sr <http://id.southampton.ac.uk/ns/inBusRoute> ?r .
    ?r <http://www.w3.org/2004/02/skos/core#notation> ?number .
    ?r rdfs:label ?name .
    ?s geo:lat ?lat .
    ?s geo:long ?long .
    ?sr <http://id.southampton.ac.uk/ns/busRouteSequenceNumber> ?seq .
  filter(regex(?number, '^U', 'i')) 
} order by ?r ?seq
");

foreach($points as $point)
{
	$routenames[$point['r']] = array($point['name'], $point['number']);
	$routes[$point['r']][$point['seq']] = array($point['long'], $point['lat']);
}

echo '<?xml version="1.0"?>';

?>
<kml xmlns="http://earth.google.com/kml/2.2">
	<Document>
		<name>Southampton Bus Routes</name>
<?php foreach($routenames as $route => $name) { ?>
		<Placemark>
			<name><?php echo $name[0]." (".$name[1].")"; ?></name>
			<description/>  
			<LineString>
				<extrude>1</extrude>
				<tessellate>1</tessellate>
				<coordinates>
<?php
$site['outline'] = explode(",", str_replace(array("POLYGON((", "))"), "", $site['outline']));
foreach($routes[$route] as $p)
{
	echo implode(',', $p).',0.000000'."\n";
}
?>

				</coordinates>
			</LineString>
		</Placemark>
<?php } ?>
	</Document>
</kml>
